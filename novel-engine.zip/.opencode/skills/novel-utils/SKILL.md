---
name: novel-utils
description: 状态管理工具层。定义7个状态文件、伏笔7态状态机、9类决策轨迹、快照保存与恢复。触发词：状态、快照、决策轨迹、伏笔管理、续写恢复。
---

# novel-utils — 状态 / 快照 / 决策轨迹

## 一、项目目录结构

```
{项目名}/
├── .novel/
│   ├── state/
│   │   ├── project-state.json      # 项目基本信息、当前阶段
│   │   ├── action-lines.json       # 角色行动线表
│   │   ├── collision-points.json   # 碰撞点表
│   │   ├── foreshadow.json         # 伏笔清单（7态）
│   │   ├── characters.json         # 角色卡摘要
│   │   ├── chapter-summaries.json  # 章节摘要
│   │   └── decision-log.json       # 决策轨迹（只追加）
│   ├── chapters/                   # 章节正文
│   ├── outline.md                  # 主线大纲
│   ├── volume.md                   # 卷纲
│   └── snapshot.md                 # 状态快照
└── scripts/                        # 辅助脚本
```

## 二、7个状态文件

| 文件 | 用途 | 关键字段 |
|------|------|----------|
| project-state.json | 项目信息 | story_name, genre, trope, golden_finger, writing_style, current_phase, current_chapter |
| action-lines.json | 行动线 | id, character, goal, direction, collision_targets, status, last_advanced_chapter |
| collision-points.json | 碰撞点 | id, name, chapter_range, characters, location, reason, result, lines_involved, status |
| foreshadow.json | 伏笔 | id, content, planted_chapter, planned_reveal, status |
| characters.json | 角色卡 | id, name, role, personality, goal, relations |
| chapter-summaries.json | 章节摘要 | chapter, title, word_count, collision, lines, summary |
| decision-log.json | 决策轨迹 | timestamp, category, decision, reason, impact |

## 三、伏笔7态状态机

```
planted → foreshadowed → reinforced → pending_reveal → revealed → resolved
                                                                   ↘ abandoned
```

| 状态 | 含义 |
|------|------|
| planted | 已埋下，读者尚未注意 |
| foreshadowed | 已暗示，读者可察觉 |
| reinforced | 已强化，多次提及 |
| pending_reveal | 即将回收 |
| revealed | 已揭示 |
| resolved | 已完全回收并闭环 |
| abandoned | 已废弃（需记录原因） |

## 四、决策轨迹（9类，只追加不覆盖）

| # | 类别 | 记录内容 |
|---|------|----------|
| 1 | 世界观决策 | 设定确认/修改 |
| 2 | 角色决策 | 新增/修改角色 |
| 3 | 行动线决策 | 推演通过/修改/否决 |
| 4 | 碰撞点决策 | 碰撞增删改 |
| 5 | 大纲决策 | 主线节点调整 |
| 6 | 卷纲决策 | 卷结构调整 |
| 7 | 章节决策 | 章纲/正文修改 |
| 8 | 伏笔决策 | 埋设/回收/废弃 |
| 9 | 文风决策 | 文风参数调整 |

**铁律：decision-log.json 只追加，永不覆盖或删除历史条目。**
续写时先读最近 3 条决策轨迹以恢复上下文。

## 五、快照机制

### 保存
在关键节点（暂停点/批量完成/会话结束）生成两份快照：
- `.novel/snapshot.md`（人类可读摘要）：当前阶段与章节、各行动线最新进度、未回收伏笔清单、最近 3 条决策轨迹、下一步计划。
- `.novel/snapshot.json`（机器可读 sidecar）：7 个状态文件的完整副本，含 `book_name`。

### 快照定位
- 快照 = 7 个状态文件的「人类可读摘要」（snapshot.md）+「机器可读 sidecar」（snapshot.json）。
- snapshot.md：给用户看；snapshot.json：给脚本用（含全部状态文件副本）。
- 恢复时**优先读状态文件**；状态文件损坏时从 sidecar 回写。
- **快照不替代状态文件**，只作为跨话题锚点；保存快照不修改状态文件。

### 书名校验
粘贴快照时，AI 先比对 `book_name` 与当前项目 `story_name`；不一致则询问：
「这份快照属于《XXX》，当前项目是《YYY》。是否切换？
A. 切换到《XXX》（切换活跃项目）
B. 将快照恢复到当前项目（覆盖当前状态）
C. 取消」

### 恢复
新会话启动时，执行与 `novel-architect` 的 `<resume-protocol>` 一致的完整流程：
1. 读取 `.novel/state/project-state.json` 获取 current_phase。
2. 读取 `.novel/snapshot.md`（人类可读摘要）。
3. 读取 `.novel/snapshot.json`（机器可读 sidecar）。
4. 读取最近 3 条 `decision-log.json` 条目。
5. 输出恢复简报（书名 / 上次写到 / 当前阶段 / 活跃行动线 / 未回收伏笔 / 最近决策 / 关键事件锚点 / 下一章目标）。
6. 询问用户「是否从第 X+1 章继续？」。
7. 用户确认后继续未完成的工作流阶段。

## 六、状态读写约定
- 所有写入采用**原子写**（写临时文件 → 重命名）。
- 状态文件损坏时，从 `snapshot.md` 恢复，不丢失已写章节。
- 每次调度子 Agent 前先读相关状态注入上下文；子 Agent 返回后更新对应状态文件。

## 七、状态分级加载

状态文件分为热数据与冷数据：

### 热数据（子 Agent 必读）
- `project-state.json`（全量）
- `action-lines.json`（只读活跃行动线，status != archived）
- `collision-points.json`（只读未完成碰撞点）
- `foreshadow.json`（只读未回收伏笔）
- `chapter-summaries.json`（只读最近 10 章）
- `decision-log.json`（只读最近 3 条）

### 冷数据（按需读取）
- 归档的行动线（status == archived）
- 已完成的碰撞点
- 已回收的伏笔
- 超过 10 章的章节摘要（合并为卷摘要后归档）
- 超过 3 条的决策轨迹

### 调度规则
- 子 Agent 默认只读热数据。
- 需要查历史时，明确指定章节号或 ID，按需读取对应冷数据。
- 状态文件超过设定阈值时，AI 主动提示：「状态文件已累积较多，建议归档冷数据。」

## 八、章节摘要压缩

规则：
1. 超过 30 章时，最早的 20 章摘要自动合并为一条「卷摘要」（约 300 字，涵盖该卷的核心事件、关键碰撞、角色变化）。
2. 卷摘要写入 `chapter-summaries.json` 的 `volume_summaries` 字段。
3. 原 20 条章节摘要移入 `archived_summaries` 字段（不删除，仅归档）。
4. 压缩触发时机：每章确认后自动检查；也可用户手动说「压缩章节摘要」。

卷摘要格式：
{
  "volume": 1,
  "chapter_range": "第1-20章",
  "core_events": ["退婚", "觉醒玉佩", "拜入宗门", "外门大比"],
  "key_collisions": ["CP-01", "CP-05", "CP-08"],
  "character_changes": ["林凡：废柴→内门弟子", "苏浅浅：退婚者→暗中相助"],
  "summary": "（300字以内的卷级摘要）"
}

## 九、备用设定管理

备用设定存储于 `.novel/state/backup-settings.json`：
{
  "backups": [
    { "id": "BK-01", "type": "golden_finger", "content": "读心术/心声流", "status": "inactive" }
  ]
}

用户指令：
- 「查看备用设定」→ 列出全部备用选项
- 「激活备用金手指：XXX」或「把备用的 XX 套路用上」→ 替换当前配置，重新执行联动校验
- 「清理备用设定」/「删除备用 XX」→ 列出供选择删除
- 备用选项上限从 user_preferences 读取（默认 10 个）

## 十、审查问题追踪

每章审查后，把 🟠 及以上问题写入 `.novel/history/issue-tracker.md`：

| 章节 | 维度 | 问题 | 状态 |
|------|------|------|------|
| 5 | 台词失真 | 配角台词像同一个人 | 已修 |
| 8 | 台词失真 | 同上 | 已修 |

规则：
- 同一维度连续 N 章出现同类问题 → 触发 🟠 提醒，AI 主动调整写作策略。
- N 从 user_preferences.review_issue_repeat_threshold 读取（默认 3）。
- 每章确认后自动检查并更新。

## 十一、按篇幅调整（work_scale）

篇幅档位（`work_scale`）决定以下机制是否启用：

### 状态分级加载
| work_scale | 是否启用 |
|------------|----------|
| short | 不启用 |
| medium | 可选（超过 20 章时启用） |
| long | 启用 |

### 章节摘要压缩
| work_scale | 是否启用 |
|------------|----------|
| short | 不启用 |
| medium | 可选 |
| long | 启用 |

### 快照机制
| work_scale | 必要性 |
|------------|--------|
| short | 可选 |
| medium | 建议 |
| long | 必需 |

### 伏笔管理
| work_scale | 伏笔数量 | 状态机 |
|------------|----------|--------|
| short | ≤3 条 | 紧凑（3态：已埋设/已回收/已废弃） |
| medium | 3-8 条 | 标准（5态） |
| long | 无上限（建议 10 条以上） | 完整（7态 + 3硬约束） |

## 知识库引用（knowledge/）

- `knowledge/13-foreshadow-rules.md` — 伏笔管理完整规则（7 态状态机 / 3 条硬约束 / 回收前 4 步自检 / 台账数据结构）。
- `knowledge/15-whitelist.md` — 审查白名单机制（`.novel/history/whitelist.md`，用户维护）。
- `knowledge/01-story-contract.md` — 故事合约，软提醒历史写入 `.novel/history/contract-warnings.md`。
